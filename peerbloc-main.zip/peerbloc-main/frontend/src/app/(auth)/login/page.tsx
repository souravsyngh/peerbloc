import LoginForm from "@/components/Login";


const LoginPage: React.FC = () => {
  return (
    <div >
      <LoginForm />
    </div>
  );
};

export default LoginPage;