import RegisterForm from "@/components/Register";


const LoginPage: React.FC = () => {
  return (
    <div className="container">
      <RegisterForm />
    </div>
  );
};

export default LoginPage;
