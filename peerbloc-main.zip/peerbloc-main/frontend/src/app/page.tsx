import Home from "@/components/Home";

const App = async () => {

  return (
    <div>
 <Home/>
    </div>
  );
};

export default App;

